import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

class Room {
    private int roomNumber;
    private String type;
    private double price;
    private boolean isAvailable;

    public Room(int roomNumber, String type, double price) {
        this.roomNumber = roomNumber;
        this.type = type;
        this.price = price;
        this.isAvailable = true;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public String getType() {
        return type;
    }

    public double getPrice() {
        return price;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    @Override
    public String toString() {
        return "Room{" +
                "roomNumber=" + roomNumber +
                ", type='" + type + '\'' +
                ", price=" + price +
                ", isAvailable=" + isAvailable +
                '}';
    }
}

class Reservation {
    private static int counter = 1;
    private int reservationId;
    private String guestName;
    private Room room;
    private Date checkInDate;
    private Date checkOutDate;

    public Reservation(String guestName, Room room, Date checkInDate, Date checkOutDate) {
        this.reservationId = counter++;
        this.guestName = guestName;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        room.setAvailable(false);
    }

    public int getReservationId() {
        return reservationId;
    }

    public String getGuestName() {
        return guestName;
    }

    public Room getRoom() {
        return room;
    }

    public Date getCheckInDate() {
        return checkInDate;
    }

    public Date getCheckOutDate() {
        return checkOutDate;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "reservationId=" + reservationId +
                ", guestName='" + guestName + '\'' +
                ", room=" + room +
                ", checkInDate=" + checkInDate +
                ", checkOutDate=" + checkOutDate +
                '}';
    }
}
class Hotel {
    private List<Room> rooms;
    private List<Reservation> reservations;

    public Hotel() {
        this.rooms = new ArrayList<>();
        this.reservations = new ArrayList<>();
    }

    public void addRoom(Room room) {
        rooms.add(room);
    }

    public List<Room> searchAvailableRooms(String type, Date checkInDate, Date checkOutDate) {
        List<Room> availableRooms = new ArrayList<>();
        for (Room room : rooms) {
            if (room.isAvailable() && room.getType().equalsIgnoreCase(type)) {
                availableRooms.add(room);
            }
        }
        return availableRooms;
    }

    public Reservation makeReservation(String guestName, Room room, Date checkInDate, Date checkOutDate) {
        Reservation reservation = new Reservation(guestName, room, checkInDate, checkOutDate);
        reservations.add(reservation);
        return reservation;
    }

    public List<Reservation> viewReservations() {
        return reservations;
    }
}
//import java.text.ParseException;
//import java.text.SimpleDateFormat;

public class Main {
    public static void main(String[] args) {
        Hotel hotel = new Hotel();

        // Add rooms to the hotel
        hotel.addRoom(new Room(101, "Single", 100.0));
        hotel.addRoom(new Room(102, "Double", 150.0));
        hotel.addRoom(new Room(103, "Suite", 300.0));

        // User Interface for simplicity
        Scanner scanner = new Scanner(System.in);
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

        while (true) {
            System.out.println("\nHotel Reservation System");
            System.out.println("1. Search available rooms");
            System.out.println("2. Make a reservation");
            System.out.println("3. View reservations");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter room type (Single/Double/Suite): ");
                    String type = scanner.next();
                    System.out.print("Enter check-in date (dd/MM/yyyy): ");
                    Date checkInDate = null;
                    Date checkOutDate = null;
                    try {
                        checkInDate = dateFormat.parse(scanner.next());
                        System.out.print("Enter check-out date (dd/MM/yyyy): ");
                        checkOutDate = dateFormat.parse(scanner.next());
                    } catch (ParseException e) {
                        System.out.println("Invalid date format.");
                        break;
                    }

                    List<Room> availableRooms = hotel.searchAvailableRooms(type, checkInDate, checkOutDate);
                    if (availableRooms.isEmpty()) {
                        System.out.println("No available rooms found.");
                    } else {
                        System.out.println("Available rooms:");
                        for (Room room : availableRooms) {
                            System.out.println(room);
                        }
                    }
                    break;
                case 2:
                    System.out.print("Enter your name: ");
                    String guestName = scanner.next();
                    System.out.print("Enter room number: ");
                    int roomNumber = scanner.nextInt();
                    Room roomToReserve = null;
                    for (Room room : hotel.searchAvailableRooms("all", null, null)) {
                        if (room.getRoomNumber() == roomNumber && room.isAvailable()) {
                            roomToReserve = room;
                            break;
                        }
                    }
                    if (roomToReserve == null) {
                        System.out.println("Invalid room number or room is not available.");
                        break;
                    }
                    System.out.print("Enter check-in date (dd/MM/yyyy): ");
                    checkInDate = null;
                    checkOutDate = null;
                    try {
                        checkInDate = dateFormat.parse(scanner.next());
                        System.out.print("Enter check-out date (dd/MM/yyyy): ");
                        checkOutDate = dateFormat.parse(scanner.next());
                    } catch (ParseException e) {
                        System.out.println("Invalid date format.");
                        break;
                    }

                    Reservation reservation = hotel.makeReservation(guestName, roomToReserve, checkInDate, checkOutDate);
                    System.out.println("Reservation successful: " + reservation);
                    break;
                case 3:
                    List<Reservation> reservations = hotel.viewReservations();
                    if (reservations.isEmpty()) {
                        System.out.println("No reservations found.");
                    } else {
                        System.out.println("Reservations:");
                        for (Reservation res : reservations) {
                            System.out.println(res);
                        }
                    }
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
